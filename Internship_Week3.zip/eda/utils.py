
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import os

def perform_eda(df, filename):
    results = {}
    results['shape'] = df.shape
    results['columns'] = df.columns.tolist()
    results['missing'] = df.isnull().sum().to_dict()
    results['types'] = df.dtypes.astype(str).to_dict()

    # Save plots
    plot_dir = 'static/plots'
    os.makedirs(plot_dir, exist_ok=True)
    for column in df.select_dtypes(include='number').columns:
        plt.figure()
        sns.histplot(df[column].dropna(), kde=True)
        plt.title(f"Distribution of {column}")
        plot_path = os.path.join(plot_dir, f"{filename}_{column}_dist.png")
        plt.savefig(plot_path)
        plt.close()

    # Correlation
    correlation_matrix = df.corr(numeric_only=True)
    plt.figure(figsize=(10, 8))
    sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm')
    heatmap_path = os.path.join(plot_dir, f"{filename}_correlation_heatmap.png")
    plt.savefig(heatmap_path)
    plt.close()

    high_corr = []
    for i in correlation_matrix.columns:
        for j in correlation_matrix.columns:
            if i != j and abs(correlation_matrix.loc[i, j]) > 0.8:
                high_corr.append((i, j, correlation_matrix.loc[i, j]))

    results['high_correlations'] = high_corr
    return results
