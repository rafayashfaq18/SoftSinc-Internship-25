
# Internship Week 3 - API and EDA

## How to Run the API

```bash
pip install -r requirements.txt
uvicorn api.main:app --reload
```

## API Endpoints

- `POST /student/` — Add a student
- `PUT /student/{id}` — Update student
- `DELETE /student/{id}` — Delete student
- `GET /student/` — Get all students
- `POST /upload-dataset/` — Upload CSV and get EDA summary

## EDA Results

- Saves distribution plots and heatmaps in `static/plots/`

## Example Dataset

Upload Titanic or Iris dataset CSV to `/upload-dataset/` endpoint.
