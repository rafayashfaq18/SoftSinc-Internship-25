
from fastapi import FastAPI, UploadFile, File, HTTPException, Depends
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
import pandas as pd
import os
from typing import List
from eda.utils import perform_eda

app = FastAPI()
students = {}

@app.post("/student/")
def add_student(id: int, name: str):
    if id in students:
        raise HTTPException(status_code=400, detail="Student ID already exists")
    students[id] = name
    return {"message": "Student added", "students": students}

@app.put("/student/{id}")
def update_student(id: int, name: str):
    if id not in students:
        raise HTTPException(status_code=404, detail="Student not found")
    students[id] = name
    return {"message": "Student updated", "students": students}

@app.delete("/student/{id}")
def delete_student(id: int):
    if id not in students:
        raise HTTPException(status_code=404, detail="Student not found")
    del students[id]
    return {"message": "Student deleted", "students": students}

@app.get("/student/")
def get_students():
    return students

@app.post("/upload-dataset/")
async def upload_dataset(file: UploadFile = File(...)):
    file_path = f"uploads/{file.filename}"
    with open(file_path, "wb") as f:
        f.write(await file.read())

    df = pd.read_csv(file_path)
    eda_result = perform_eda(df, file.filename)
    return JSONResponse(content=eda_result)
